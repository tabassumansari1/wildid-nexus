"""Individual animal re-identification from photos and video frames.

This is the classic wildlife mark-recapture approach used by tools such as
HotSpotter, not a face-recognition model and not a guess from body pose.

For every file we:
  1. Pull a sharp view (a still, or the sharpest frames of a clip).
  2. Describe markings with SIFT, on the full frame and on a saliency crop.
  3. Keep only matches that survive a geometric check (RANSAC affine).
  4. Call same / different / inconclusive from the inlier count.
  5. Group files that passed as the same individual.

Pose, mouth movement and "it is also a tiger" are not identity. Two tigers
share a skeleton. Identity here is the geometry of spots, stripes and scars.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 36_000_000

MAX_SIDE = 960
DIFFERENT_INLIERS = 9
NEAR_DUP_HAMMING = 10


class EngineError(ValueError):
    pass


@dataclass
class View:
    image: np.ndarray
    keypoints: list
    descriptors: np.ndarray | None
    sharpness: float
    tag: str


@dataclass
class Signature:
    file_id: str
    name: str
    kind: str
    views: list[View]
    digest: np.ndarray
    quality: str
    point_count: int
    preview_name: str = ""
    note: str = ""


@dataclass
class PairResult:
    a: str
    b: str
    verdict: str
    score: int
    inliers: int
    good: int
    reason: str
    evidence_name: str = ""
    low_quality: bool = False


def analyze(items: list[dict], out_dir: Path, media_url: str) -> dict:
    """Compare a batch of media files and write thumbs plus match sheets.

    Each item needs id, name, path, kind ("image" or "video").
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if not media_url.endswith("/"):
        media_url += "/"

    signatures: list[Signature] = []
    skipped: list[dict] = []
    for item in items:
        try:
            signature = _signature_for(item, out_dir)
        except EngineError as exc:
            skipped.append({"name": item["name"], "reason": str(exc)})
            continue
        signatures.append(signature)

    if len(signatures) < 2:
        detail = ""
        if skipped:
            detail = " " + " ".join(f"{s['name']}: {s['reason']}" for s in skipped)
        raise EngineError(
            "Need at least two readable photos or videos to compare." + detail
        )

    pairs = [_compare(a, b, out_dir) for i, a in enumerate(signatures) for b in signatures[i + 1 :]]
    rank = {"same": 0, "uncertain": 1, "different": 2}
    pairs.sort(key=lambda pair: (rank[pair.verdict], -pair.score))
    _attach_evidence(pairs, signatures, out_dir)
    individuals = _cluster(signatures, pairs)
    summary = _summarize(signatures, pairs, individuals)

    def url_for(name: str) -> str:
        if not name:
            return ""
        relative = Path(out_dir.name) / name
        # out_dir is MEDIA_ROOT/reports/<scan>
        parent = out_dir.parent.name
        return f"{media_url}{parent}/{out_dir.name}/{name}"

    by_id = {sig.file_id: sig for sig in signatures}
    files_out = []
    for sig in signatures:
        files_out.append(
            {
                "id": sig.file_id,
                "name": sig.name,
                "kind": sig.kind,
                "quality": sig.quality,
                "points": sig.point_count,
                "note": sig.note,
                "preview": url_for(sig.preview_name),
            }
        )
    file_card = {row["id"]: row for row in files_out}
    for individual in individuals:
        individual["files"] = [file_card[file_id] for file_id in individual["file_ids"]]

    pairs_out = []
    for pair in pairs:
        pairs_out.append(
            {
                "a": pair.a,
                "b": pair.b,
                "a_name": by_id[pair.a].name,
                "b_name": by_id[pair.b].name,
                "verdict": pair.verdict,
                "score": pair.score,
                "inliers": pair.inliers,
                "good": pair.good,
                "reason": pair.reason,
                "evidence": url_for(pair.evidence_name),
            }
        )

    return {
        "summary": summary,
        "files": files_out,
        "pairs": pairs_out,
        "individuals": individuals,
        "skipped": skipped,
        "method": (
            "SIFT markings on each animal region, kept only when they agree "
            "under one geometric transform (RANSAC). Same family as HotSpotter, "
            "the classic wildlife re-identification matcher. Pose is not used."
        ),
    }


def _signature_for(item: dict, out_dir: Path) -> Signature:
    kind = item["kind"]
    path = Path(item["path"])
    if kind == "video":
        frames = _video_frames(path)
        views = []
        for sharp, _index, at, image in frames:
            tag = f"{at:.1f}s" if at is not None else "frame"
            views.append(_describe(image, tag))
        note = f"{len(views)} sharp frames sampled"
    else:
        image = _load_image(path)
        if image is None:
            raise EngineError("Could not read this image.")
        full = _describe(image, "full")
        crop = _animal_crop(image)
        views = [full]
        if crop is not None:
            views.append(_describe(crop, "animal region"))
        note = f"{len(views[0].keypoints)} marking points"

    if not views or all(v.descriptors is None or len(v.keypoints) < 8 for v in views):
        raise EngineError("No stable markings found. Try a closer, sharper view of the coat.")

    best = max(views, key=lambda v: len(v.keypoints))
    quality = "good"
    if best.sharpness < 18 or len(best.keypoints) < 40:
        quality = "weak"
        note = "Soft or sparse detail — treat a mismatch as inconclusive"

    preview = views[0].image
    preview_name = f"{item['id']}-preview.jpg"
    _write_jpeg(preview, out_dir / preview_name, max_side=720)

    return Signature(
        file_id=str(item["id"]),
        name=item["name"],
        kind=kind,
        views=views,
        digest=_dhash(views[0].image),
        quality=quality,
        point_count=len(best.keypoints),
        preview_name=preview_name,
        note=note,
    )


def _compare(a: Signature, b: Signature, out_dir: Path) -> PairResult:
    hamming = int(np.count_nonzero(a.digest != b.digest))
    best = None
    best_views = None
    for va in a.views:
        for vb in b.views:
            matched = _match(va, vb)
            rank = (matched["inliers"], matched["ratio"])
            if best is None or rank > (best["inliers"], best["ratio"]):
                best = matched
                best_views = (va, vb)
    assert best is not None and best_views is not None
    low = a.quality == "weak" or b.quality == "weak"
    verdict = _verdict(best["inliers"], best["ratio"], hamming, low)
    score = _score(verdict, best["inliers"], best["ratio"])
    reason = _reason(verdict, best["inliers"], best["good"], hamming, low, a, b)
    pair = PairResult(
        a=a.file_id,
        b=b.file_id,
        verdict=verdict,
        score=score,
        inliers=best["inliers"],
        good=best["good"],
        reason=reason,
        low_quality=low,
    )
    pair._views = best_views  # type: ignore[attr-defined]
    pair._matched = best  # type: ignore[attr-defined]
    return pair


def _verdict(inliers: int, ratio: float, hamming: int, low: bool) -> str:
    if hamming <= NEAR_DUP_HAMMING:
        return "same"
    # Ratio matters more than raw count. A smooth body outline can produce a
    # handful of geometrically consistent points across two different coats.
    confident = inliers >= 18 and ratio >= 0.42
    many = inliers >= 48 and ratio >= 0.32
    if confident or many:
        if low and inliers < 40 and ratio < 0.55:
            return "uncertain"
        return "same"
    if low:
        return "uncertain"
    if inliers <= DIFFERENT_INLIERS:
        return "different"
    return "uncertain"


def _score(verdict: str, inliers: int, ratio: float) -> int:
    if verdict == "same":
        value = 72 + ratio * 22 + min(inliers, 120) / 30
        return int(max(70, min(99, round(value))))
    if verdict == "different":
        return int(max(4, min(28, 6 + inliers * 2)))
    return int(max(32, min(68, 34 + min(inliers, 20) * 1.4)))


def _reason(verdict: str, inliers: int, good: int, hamming: int, low: bool, a: Signature, b: Signature) -> str:
    if hamming <= NEAR_DUP_HAMMING and verdict == "same":
        return "These are the same frame, or a trivial re-export of it."
    if verdict == "same":
        where = ""
        if a.kind == "video" or b.kind == "video":
            where = " Best frames from the clip were used, not mouth movement or gait."
        return (
            f"{inliers} marking points agree under a single geometric transform "
            f"({good} candidates checked). That is the same coat, not just the same species."
            + where
        )
    if verdict == "different":
        return (
            f"Only {inliers} correspondences survived the geometry check "
            f"out of {good} lookalikes. Shared pose or colour is not enough — the markings disagree."
        )
    if low:
        return (
            "One of these views is too soft, small, or occluded to decide. "
            "A mismatch here would be a guess, so it stays inconclusive."
        )
    return (
        f"{inliers} points line up, which is more than chance and less than a confident match. "
        "Use a clearer flank, face, or rump shot before calling this."
    )


def _attach_evidence(pairs: list[PairResult], signatures: list[Signature], out_dir: Path) -> None:
    interesting = [p for p in pairs if p.verdict in {"same", "uncertain"} and p.inliers >= 6]
    if not interesting:
        different = [p for p in pairs if p.verdict == "different"]
        if different:
            interesting = [max(different, key=lambda p: p.inliers)]
    for pair in interesting:
        views = getattr(pair, "_views", None)
        matched = getattr(pair, "_matched", None)
        if not views or not matched or matched["draw"] is None:
            continue
        left, right = views
        name = f"pair-{pair.a}-{pair.b}.jpg"
        canvas = cv2.drawMatches(
            left.image,
            left.keypoints,
            right.image,
            right.keypoints,
            matched["draw"],
            None,
            matchColor=(40, 110, 70),
            singlePointColor=(180, 180, 180),
            flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
        )
        _write_jpeg(canvas, out_dir / name, max_side=1400)
        pair.evidence_name = name


def _cluster(signatures: list[Signature], pairs: list[PairResult]) -> list[dict]:
    parent = {sig.file_id: sig.file_id for sig in signatures}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(x: str, y: str) -> None:
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[ry] = rx

    for pair in pairs:
        if pair.verdict == "same":
            union(pair.a, pair.b)

    groups: dict[str, list[str]] = {}
    for sig in signatures:
        groups.setdefault(find(sig.file_id), []).append(sig.file_id)

    # Largest groups first, then stable by first member order.
    ordered = sorted(groups.values(), key=lambda members: (-len(members), members[0]))
    letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    individuals = []
    pair_index = {(p.a, p.b): p for p in pairs}
    for index, members in enumerate(ordered):
        label = letters[index] if index < len(letters) else str(index + 1)
        scores = []
        for i, left in enumerate(members):
            for right in members[i + 1 :]:
                pair = pair_index.get((left, right)) or pair_index.get((right, left))
                if pair and pair.verdict == "same":
                    scores.append(pair.score)
        alone = len(members) == 1
        individuals.append(
            {
                "id": label,
                "title": f"Individual {label}",
                "file_ids": members,
                "agreement": None if alone or not scores else int(min(scores)),
                "alone": alone,
            }
        )
    return individuals


def _summarize(signatures: list[Signature], pairs: list[PairResult], individuals: list[dict]) -> dict:
    n = len(signatures)
    k = len(individuals)
    kinds = {p.verdict for p in pairs}
    if k == 1:
        return {
            "verdict": "same",
            "kicker": "Same animal",
            "headline": "These files are one individual.",
            "dek": "Coat geometry agrees across this set. The group below is a single animal, seen more than once.",
            "individuals": k,
            "files": n,
        }
    if k == n and kinds == {"different"}:
        noun = "animal" if n == 2 else "animals"
        return {
            "verdict": "different",
            "kicker": "Different animals",
            "headline": f"These are {n} different {noun}." if n > 2 else "These are not the same individual.",
            "dek": "Markings do not share a geometric match. Same species is not the same animal.",
            "individuals": k,
            "files": n,
        }
    if k == n and "same" not in kinds:
        return {
            "verdict": "uncertain",
            "kicker": "Inconclusive",
            "headline": "Not enough evidence to decide.",
            "dek": "Nothing here is a confident match, and a confident rejection would overclaim. Shoot the flank, face, or rump again.",
            "individuals": k,
            "files": n,
        }
    return {
        "verdict": "mixed",
        "kicker": f"{k} individuals",
        "headline": f"{n} files resolve to {k} animals.",
        "dek": "Grouped files matched each other. Files in different groups did not.",
        "individuals": k,
        "files": n,
    }


def _load_image(path: Path) -> np.ndarray | None:
    try:
        with Image.open(path) as im:
            im = im.convert("RGB")
            w, h = im.size
            scale = MAX_SIDE / max(w, h)
            if scale < 1:
                im = im.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.Resampling.LANCZOS)
            rgb = np.asarray(im)
            if rgb.ndim != 3 or rgb.shape[2] != 3:
                return None
            return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    except (UnidentifiedImageError, OSError, ValueError):
        image = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if image is None:
            return None
        return _resize_max(image, MAX_SIDE)


def _video_frames(path: Path) -> list[tuple[float, int, float | None, np.ndarray]]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise EngineError("Could not read this video. Use MP4, MOV, AVI, MKV, or WEBM.")
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0) or 0.0
    picked: list[tuple[int, np.ndarray]] = []
    try:
        if 0 < total < 100000:
            indexes = np.linspace(0, total - 1, num=min(12, total), dtype=int)
            seen: set[int] = set()
            for index in indexes:
                index = int(index)
                if index in seen:
                    continue
                seen.add(index)
                cap.set(cv2.CAP_PROP_POS_FRAMES, index)
                ok, frame = cap.read()
                if ok and frame is not None:
                    picked.append((index, frame))
        else:
            index = 0
            while len(picked) < 12 and index < 360:
                ok, frame = cap.read()
                if not ok or frame is None:
                    break
                if index % 3 == 0:
                    picked.append((index, frame))
                index += 1
    finally:
        cap.release()
    if not picked:
        raise EngineError("This video has no readable frames.")
    scored = []
    for index, frame in picked:
        image = _resize_max(frame, 720)
        sharp = _sharpness(image)
        at = (index / fps) if fps else None
        scored.append((sharp, index, at, image))
    scored.sort(key=lambda row: row[0], reverse=True)
    keep = scored[:4]
    keep.sort(key=lambda row: row[1])
    return keep


def _describe(image: np.ndarray, tag: str) -> View:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    sift = cv2.SIFT_create(nfeatures=800, contrastThreshold=0.04, edgeThreshold=12)
    keypoints, descriptors = sift.detectAndCompute(gray, None)
    if descriptors is not None:
        descriptors = np.asarray(descriptors, dtype=np.float32)
    return View(
        image=image,
        keypoints=keypoints or [],
        descriptors=descriptors,
        sharpness=_sharpness(image),
        tag=tag,
    )


def _animal_crop(image: np.ndarray) -> np.ndarray | None:
    """Center-biased spectral saliency. Falls back to no crop when unsure."""
    try:
        saliency = cv2.saliency.StaticSaliencySpectralResidual_create()
        ok, sal_map = saliency.computeSaliency(image)
    except cv2.error:
        return None
    if not ok or sal_map is None:
        return None
    sal_map = sal_map.astype(np.float32)
    height, width = sal_map.shape[:2]
    ys = np.linspace(-1, 1, height, dtype=np.float32)[:, None]
    xs = np.linspace(-1, 1, width, dtype=np.float32)[None, :]
    bias = np.exp(-((xs ** 2) + (ys ** 2)) / 0.85)
    weighted = sal_map * (0.40 + 0.60 * bias)
    span = float(np.ptp(weighted)) + 1e-6
    weighted = (weighted - float(weighted.min())) / span
    mask = (weighted > 0.55).astype(np.uint8) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    contour = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(contour)
    if w * h < 0.10 * width * height or w * h > 0.90 * width * height:
        return None
    pad_x, pad_y = int(w * 0.10), int(h * 0.10)
    x0, y0 = max(0, x - pad_x), max(0, y - pad_y)
    x1, y1 = min(width, x + w + pad_x), min(height, y + h + pad_y)
    crop = image[y0:y1, x0:x1]
    if crop.size == 0 or min(crop.shape[:2]) < 48:
        return None
    return crop


def _match(left: View, right: View) -> dict:
    empty = {"inliers": 0, "good": 0, "ratio": 0.0, "draw": None}
    da, db = left.descriptors, right.descriptors
    if da is None or db is None or len(left.keypoints) < 8 or len(right.keypoints) < 8:
        return empty
    matcher = cv2.FlannBasedMatcher(dict(algorithm=1, trees=5), dict(checks=40))
    try:
        knn = matcher.knnMatch(da, db, k=2)
    except cv2.error:
        return empty
    good = []
    for pair in knn:
        if len(pair) < 2:
            continue
        primary, secondary = pair
        if primary.distance < 0.75 * secondary.distance:
            good.append(primary)
    inliers = 0
    draw = None
    if len(good) >= 8:
        src = np.float32([left.keypoints[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([right.keypoints[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        _affine, mask = cv2.estimateAffinePartial2D(
            src,
            dst,
            method=cv2.RANSAC,
            ransacReprojThreshold=6.0,
            maxIters=2000,
            confidence=0.99,
        )
        if mask is not None:
            flat = mask.reshape(-1).astype(bool)
            inliers = int(flat.sum())
            chosen = [m for m, keep in zip(good, flat) if keep]
            chosen.sort(key=lambda m: m.distance)
            draw = chosen[:40]
    ratio = inliers / len(good) if good else 0.0
    return {"inliers": inliers, "good": len(good), "ratio": float(ratio), "draw": draw}


def _dhash(image: np.ndarray, hash_size: int = 8) -> np.ndarray:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    small = cv2.resize(gray, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)
    return (small[:, 1:] > small[:, :-1]).flatten()


def _sharpness(image: np.ndarray) -> float:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def _resize_max(image: np.ndarray, max_side: int) -> np.ndarray:
    height, width = image.shape[:2]
    scale = max_side / max(height, width)
    if scale >= 1:
        return image
    return cv2.resize(image, (max(1, int(width * scale)), max(1, int(height * scale))), interpolation=cv2.INTER_AREA)


def _write_jpeg(image: np.ndarray, path: Path, max_side: int = 960) -> None:
    image = _resize_max(image, max_side)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), image, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
