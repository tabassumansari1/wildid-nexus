(function () {
  var form = document.getElementById("scan-form");
  var input = document.getElementById("files");
  var list = document.getElementById("file-list");
  var submit = document.getElementById("submit");
  var hint = document.getElementById("hint");
  var drop = document.getElementById("drop");
  var overlay = document.getElementById("overlay");
  var errorBox = document.getElementById("form-error");
  var sampleData = document.getElementById("sample-data");
  if (!form || !input) return;

  var packs = {};
  try {
    packs = JSON.parse(sampleData.textContent);
  } catch (err) {
    packs = {};
  }

  function csrf() {
    var match = document.cookie.match(/csrftoken=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : "";
  }

  function showError(message) {
    if (!errorBox) return;
    errorBox.hidden = false;
    errorBox.textContent = message;
  }

  function render() {
    var files = Array.prototype.slice.call(input.files || []);
    list.innerHTML = "";
    if (!files.length) {
      list.hidden = true;
    } else {
      list.hidden = false;
      files.forEach(function (file, index) {
        var item = document.createElement("li");
        var name = document.createElement("span");
        name.textContent = file.name;
        var meta = document.createElement("small");
        meta.textContent = file.type.indexOf("video") === 0 ? "Video" : "Photo";
        var remove = document.createElement("button");
        remove.type = "button";
        remove.textContent = "Remove";
        remove.addEventListener("click", function () {
          var next = new DataTransfer();
          files.forEach(function (candidate, candidateIndex) {
            if (candidateIndex !== index) next.items.add(candidate);
          });
          input.files = next.files;
          render();
        });
        item.appendChild(name);
        item.appendChild(meta);
        item.appendChild(remove);
        list.appendChild(item);
      });
    }
    var ready = files.length >= 2;
    submit.disabled = !ready;
    hint.textContent = ready
      ? files.length + " files ready."
      : "Add at least two files.";
  }

  input.addEventListener("change", render);

  ["dragenter", "dragover"].forEach(function (name) {
    drop.addEventListener(name, function (event) {
      event.preventDefault();
      drop.classList.add("is-hot");
    });
  });
  ["dragleave", "drop"].forEach(function (name) {
    drop.addEventListener(name, function (event) {
      event.preventDefault();
      drop.classList.remove("is-hot");
    });
  });
  drop.addEventListener("drop", function (event) {
    if (!event.dataTransfer || !event.dataTransfer.files.length) return;
    input.files = event.dataTransfer.files;
    render();
  });

  document.querySelectorAll("[data-pack]").forEach(function (button) {
    button.addEventListener("click", function () {
      var urls = packs[button.getAttribute("data-pack")] || [];
      button.disabled = true;
      Promise.all(
        urls.map(function (url) {
          return fetch(url).then(function (response) {
            if (!response.ok) throw new Error("Sample failed to load.");
            return response.blob().then(function (blob) {
              var name = url.split("/").pop();
              return new File([blob], name, { type: blob.type || "image/jpeg" });
            });
          });
        })
      )
        .then(function (files) {
          var next = new DataTransfer();
          files.forEach(function (file) { next.items.add(file); });
          input.files = next.files;
          render();
        })
        .catch(function () {
          showError("Could not load the sample set. Check that you opened Pugmark from its own address.");
        })
        .then(function () {
          button.disabled = false;
        });
    });
  });

  form.addEventListener("submit", function (event) {
    if (!window.fetch || !window.FormData) return;
    event.preventDefault();
    if (submit.disabled) return;
    overlay.hidden = false;
    if (errorBox) errorBox.hidden = true;
    submit.disabled = true;
    fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: {
        "X-Requested-With": "XMLHttpRequest",
        "X-CSRFToken": csrf(),
      },
    })
      .then(function (response) {
        return response.json().then(function (data) {
          return { ok: response.ok, status: response.status, data: data };
        });
      })
      .then(function (result) {
        if (result.data && result.data.report_url && (result.ok || result.status === 422)) {
          window.location.assign(result.data.report_url);
          return;
        }
        throw new Error((result.data && result.data.error) || "Could not compare these files.");
      })
      .catch(function (err) {
        overlay.hidden = true;
        submit.disabled = false;
        showError(err.message || "Could not compare these files.");
      });
  });
})();
